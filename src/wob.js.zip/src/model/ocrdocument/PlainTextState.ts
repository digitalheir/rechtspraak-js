
export interface PlainTextState {
    batchid: string;
    fullText: string;
    loading?: boolean;
}