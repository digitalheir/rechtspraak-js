import {NormalizedVertex, ParagraphBlock, VisionBlock, WordBox} from "./ReconstructedDoc";
import {roundTo100s} from "../util/numberutils";

export function cssSmallestCoordinateAsPx(
    arr: NormalizedVertex[] | undefined,
    fractionOf: number | undefined,
    selectCoordinate: (v: NormalizedVertex) => number | undefined
): string | undefined {
    if (!!arr && fractionOf !== undefined) {
        let smallestNumber = undefined;
        for (let vertex of arr) {
            const num = selectCoordinate(vertex);
            if (num !== undefined && (smallestNumber === undefined || smallestNumber > num)) smallestNumber = num;
        }
        if (smallestNumber !== undefined) return `${fractionOf * smallestNumber}px`;
        else return undefined;
    }
}

export function cssSmallestCoordinateScaled(
    arr: NormalizedVertex[] | undefined,
    fractionOf: number | undefined,
    selectCoordinate: (v: NormalizedVertex) => number | undefined
): number | undefined {
    if (!!arr && fractionOf !== undefined) {
        let smallestNumber = undefined;
        for (let vertex of arr) {
            const num = selectCoordinate(vertex);
            if (num !== undefined && (smallestNumber === undefined || smallestNumber > num)) smallestNumber = num;
        }
        if (smallestNumber !== undefined) return fractionOf * smallestNumber;
        else return undefined;
    }
}

export function cssLargestCoordinateAsPx(
    arr: NormalizedVertex[] | undefined,
    fractionOf: number | undefined,
    selectCoordinate: (v: NormalizedVertex) => number | undefined
): string | undefined {
    if (!!arr && fractionOf !== undefined) {
        let largest = undefined;
        for (let vertex of arr) {
            const num = selectCoordinate(vertex);
            if (num !== undefined && (largest === undefined || largest < num)) largest = num;
        }
        if (largest !== undefined) return `${fractionOf * largest}px`;
        else return undefined;
    }
}

export function determineLargestDifferenceAsPx(
    arr: NormalizedVertex[] | undefined,
    fractionOf: number | undefined,
    selectCoordinate: (v: NormalizedVertex) => number | undefined
): number | undefined {
    if (!!arr && fractionOf !== undefined) {
        let smallestNumber = undefined;
        let largestNumber = undefined;
        for (let vertex of arr) {
            const num = selectCoordinate(vertex);
            if (num !== undefined) {
                if (largestNumber === undefined || largestNumber < num) largestNumber = num;
                if (smallestNumber === undefined || smallestNumber > num) smallestNumber = num;
            }
        }
        if (largestNumber !== undefined && smallestNumber !== undefined) return fractionOf * (largestNumber - smallestNumber);
        else return undefined;
    }
}

export function determineSmallestDistance(arr: NormalizedVertex[] | undefined, width: number | undefined, height: number | undefined) {
    if (!!arr) {
        let lowestY: number | undefined = undefined;
        let highestY = 0;
        let lowestX: number | undefined = undefined;
        let highestX = 0;
        for (let vertex of arr) {
            const y = vertex?.y;
            if (typeof y === "number") {
                if (y > highestY) highestY = y;
                if (lowestY === undefined || y < lowestY) lowestY = y;
            }
            const x = vertex?.x;
            if (typeof x === "number") {
                if (x > highestX) highestX = x;
                if (lowestX === undefined || x < lowestX) lowestX = x;
            }
        }
        // console.log(`${highestY} - ${lowestY} = ${roundTo100s(100 * (highestY - lowestY))}%`);
        const heightDiff = typeof lowestY === "number" ? highestY - lowestY : undefined;
        const widthDiff = typeof lowestX === "number" ? highestX - lowestX : undefined;
        if (heightDiff && widthDiff) {
            if ((width === undefined || heightDiff < widthDiff) && height !== undefined) return heightDiff * height;
            else if (width !== undefined) return widthDiff * width;
            else return undefined;
        } else if (heightDiff && height !== undefined) return heightDiff * height;
        else if (widthDiff && width !== undefined) return widthDiff * width;
        else return undefined;
    } else {
        return undefined
    }
}

export function determineSmallestHeight(arr: NormalizedVertex[] | undefined, height: number | undefined) {
    if (!!arr && height !== undefined) {
        let lowestY: number | undefined = undefined;
        let highestY = 0;
        for (let vertex of arr) {
            const y = vertex?.y;
            if (typeof y === "number") {
                if (y > highestY) highestY = y;
                if (lowestY === undefined || y < lowestY) lowestY = y;
            }
        }
        // console.log(`${highestY} - ${lowestY} = ${roundTo100s(100 * (highestY - lowestY))}%`);
        const heightDiff = typeof lowestY === "number" ? highestY - lowestY : undefined;
        return heightDiff ? heightDiff * height : undefined;
    } else {
        return undefined
    }
}

function hasAscender(text: string) {
    return (text.toUpperCase() === text) || !!text.match(/[bdfhijklt!?]/);
}

function hasDescender(text: string) {
    return !!text.match(/[pjqy]/);
}


function determineSizeFactor(word: WordBox) {
    let ascenderFound = false;
    let descenderFound = false;
    for (let sym of word.symbols) {
        const text = sym.text;
        if (!ascenderFound && text && hasAscender(text)) ascenderFound = true;
        if (!descenderFound && text && hasDescender(text)) descenderFound = true;
        if (ascenderFound && descenderFound) break;
    }
    const ascenderFraction = 0.015;
    const descenderFraction = 0.01;
    return 0.7 - (ascenderFound ? ascenderFraction : 0) - (descenderFound ? descenderFraction : 0);
}

export function determineAverageFontSize(paragraph: ParagraphBlock, height: number | undefined): string | undefined {
    if(height === undefined) return undefined;
    const words = paragraph.words;
    let cum = 0
    let wordCount = words.length;
    for (let word of words) {
        const verticesWord = word.boundingBox?.normalizedVertices;
        const availableSpace = determineSmallestHeight(verticesWord, height);
        const fontSize = typeof availableSpace === "number" ? determineSizeFactor(word) * availableSpace : undefined;
        if(typeof fontSize === "number") {
            cum += fontSize;
        } else {
            wordCount--;
        }
    }
    const avg = cum / wordCount;
    return `${roundTo100s(avg)}px`
}


export function smallestOf(blocks: VisionBlock[], fn: (bl: NormalizedVertex) => number | undefined) {
    let smallest = undefined;
    for(let block of blocks) {
        for(let paragraph of block.paragraphs) {
            for(let vertex of paragraph.boundingBox.normalizedVertices) {
                const nr = fn(vertex);
                if (nr !== undefined && (smallest === undefined || smallest > nr)) smallest = nr;
            }
        }
    }
    return smallest;
}


export function largestOf(blocks: VisionBlock[], fn: (bl: NormalizedVertex) => number | undefined) {
    let largest = undefined;
    for(let block of blocks) {
        for(let paragraph of block.paragraphs) {
            for(let vertex of paragraph.boundingBox.normalizedVertices) {
                const nr = fn(vertex);
                if (nr !== undefined && (largest === undefined || largest < nr)) largest = nr;
            }
        }
    }
    return largest;
}
