import {API_WETTEN_WOB, HTTP_ROOT_WOB, urlToDocJson} from "../lawly/WebsiteConstants";
import {OcrDoc, OcrPage, ReconstructedDoc, ReconstructedPage} from "./ReconstructedDoc";
import {firstElementOf} from "../util/arrayutils";
import {PlainTextState} from "./PlainTextState";
import {ProcessingDocWithTitle} from "../batchstatus/ProcessingDoc";

export interface ProcessingDocsState {
    results: ProcessingDocWithTitle[];
    err?: Error;
    loading?: boolean;
}

export interface ProcessedDoc {
    tgMsgId: number;
    fileName: string;
    title: string;
}

export interface ProcessedDocWithBatchId extends ProcessedDoc, PlainTextState {
    err?: Error;
}

export async function fetchMetadataForDoc(docIdInBatch: string): Promise<ProcessedDocWithBatchId> {
    // todo store these meta files statically on wob.lareader.nl!
    //                            `${HTTP_ROOT_WOB}/meta/${batchid}.json`;
    const res = await fetch(`${API_WETTEN_WOB}/meta/${docIdInBatch}.json`);
    const newVar = await res.json();
    //throw Error("Fake error")
    return Object.assign(
        {
            batchid: docIdInBatch,
        },
        newVar,
    );
}

export async function getPlainTextForDoc(docIdInBatch: string): Promise<string> {
    const res = await fetch(`${API_WETTEN_WOB}/text/${docIdInBatch}`);
    return await res.text();
}

function firstPage(page: OcrPage) {
    return page.pageNumber || 0;
}

// export async function getReconstructedPages(docIdInBatch: string): Promise<ReconstructedDoc> {
//     const res = await fetch(`${API_WETTEN_WOB}/reconstructed/${docIdInBatch}.json`);
//     const pages = await res.json() as ReconstructedPage[];
//     //throw Error("Sneaky error");
//     return {id: docIdInBatch, pages: pages.sort((a, b) => firstPage(a) - firstPage(b))}
// }
export async function getReconstructedPages(docIdInBatch: string): Promise<ReconstructedDoc> {
    // https://wob.lawreader.nl/consolidated/bijlagen_b941.json.gz?h=gzjson

    // NOTE: This STRONGLY depends on our Cloudflare config to transform the HTTP headers of 'h=gzjson' params so that the browser can make sense of the response
    const res = await fetch(`${urlToDocJson(docIdInBatch)}?h=gzjson`);
    const doc = await res.json() as OcrDoc;
    const pages = doc.pages;
    //.sort((a, b) => firstPage(a) - firstPage(b))
    //throw Error("Sneaky error");
    return {id: docIdInBatch, pages}
}