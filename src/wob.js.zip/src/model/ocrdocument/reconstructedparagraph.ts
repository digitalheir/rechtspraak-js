import {WordBox} from "./ReconstructedDoc";

export function extraChar(detectedBreak: string | undefined): number {
    if (!detectedBreak) return 0;
    else switch (detectedBreak) {
        case "SPACE":
            return 1;

        case "LINE_BREAK":
            return 1; // line break could happen because of document width; treat as space
        case "EOL_SURE_SPACE":
            return -1; // Larger break than ordinary; treat as <br/> (force break)

        default:
            return 0 //???
    }
}

export function joinString(word: WordBox): (string | number)[] {
    const entireString: (string | number)[] = [];
    let currentStr: string[] = [];
    word.symbols.forEach(symbol => {
        const txt = symbol.text;
        if (txt) currentStr.push(txt);
        switch (extraChar(symbol.property?.detectedBreak?.type)) {
            case 1:
                currentStr.push(" ");
                break;
            case -1:
                entireString.push(currentStr.join(""))
                currentStr = [];
                entireString.push(-1);
                break;
        }
    });
    if (currentStr.length > 0) entireString.push(currentStr.join(""));
    return entireString;
}
