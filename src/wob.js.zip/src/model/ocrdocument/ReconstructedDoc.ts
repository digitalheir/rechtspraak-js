


export interface GcsSource {
    uri: string;
}

export interface InputConfig {
    gcsSource: GcsSource;
}

export interface DetectedLanguage {
    languageCode: string;
    confidence: number;
}

export interface NormalizedVertex {
    x?: number;
    y?: number;
}

export interface BoundingBox {
    normalizedVertices: NormalizedVertex[]
}

export interface ParagraphBlock {
    boundingBox: BoundingBox;
    confidence: number;
    property?: LanguagesDetected;
    words: WordBox[];
}

export interface DetectedBreak {
    type: string;
}

export interface SymbolProperty {
    detectedBreak?: DetectedBreak
}

export interface VisionSymbol {
    text: string;
    confidence?: number;
    property?: SymbolProperty;
}

export interface WordBox {
    symbols: VisionSymbol[];

    boundingBox: BoundingBox;
}

export interface VisionBlock {
    paragraphs: ParagraphBlock[];

    boundingBox: BoundingBox;
}

export interface LanguagesDetected {
    detectedLanguages?: DetectedLanguage[];
}
export interface VisionProperty extends LanguagesDetected {
    //blocks: VisionBlock[]
}

export interface VisionPage {
    property: VisionProperty;
    blocks: VisionBlock[];
    width?: number;
    height?: number;
    confidence?: number;
}

export interface FullTextAnnotation {
    pages: VisionPage[];
}

interface ResponseContext {
    pageNumber?: number;
}
export interface VisionResponse {
    fullTextAnnotation?: FullTextAnnotation;
    context: ResponseContext;
}

export interface ReconstructedPage {
    inputConfig: InputConfig;
    responses: VisionResponse[];
}
export interface ReconstructedDoc {
    id: string;
    err?: Error;
    pages: OcrPage[];
}

export interface OcrDoc {
    fileId: string;
    batchId: string;
    telegramMessage: any;//TelegramMessage
    pages: OcrPage[];
}

export interface OcrPage {
    pageNumber: number;
    page?: Page;
}

export interface Page {
    text: string;
    blocks: VisionBlock[];

    width: number;
    height: number;
    property?: VisionProperty;
    confidence?: number;
}
