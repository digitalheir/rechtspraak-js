
export function firstElementOf<T>(arr: T[] | undefined) {
    return (arr && arr.length) ? arr[0] : undefined;
}