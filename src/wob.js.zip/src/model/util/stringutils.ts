import {roundTo100s} from "./numberutils";

export function cssPercentage(num: number | undefined) {
    if (num) {
        return `${roundTo100s(num * 100)}%`
    } else {
        return undefined;
    }
}

export function appendIfDefined(src: number | undefined, appendNumber: number, appendString: string) {
    if (src) {
        return `${src + appendNumber}${appendString}`
    } else {
        return undefined;
    }
}

export function appendPx(src: number | undefined): string | undefined {
    return appendStrIfDefined(src, "px")
}

export function appendStrIfDefined(src: number | undefined, appendString: string): string | undefined {
    if (src) {
        return `${src}${appendString}`
    } else {
        return undefined;
    }
}


export function appendStr(src: number, appendString: string) {
    return `${src}${appendString}`;
}
