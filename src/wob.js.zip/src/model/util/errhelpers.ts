
export function normalizeError(e: any): Error {
    if (typeof e === "string") {
        return Error(e);
    } else if (e instanceof Error) {
        return e;
    } else {
        return Error("Unknown error :S");
    }
}