

export function roundTo100s(num: number) {
    return Math.round((num + Number.EPSILON) * 100) / 100;
}
export function times(factor: number, num: number | undefined): number | undefined {
    return typeof num === "number" ? num * factor : undefined;
}
export function timesIfDefined(factor: number | undefined, num: number | undefined): number | undefined {
    return typeof num === "number" && typeof factor === "number" ? num * factor : undefined;
}

export function minus(num: number, factorOr0: number | undefined): number {
    const minusN = factorOr0 ? factorOr0 : 0;
    return num - minusN;
}

export function minusIfDefined(num: number | undefined, factorOr0: number | undefined): number | undefined{
    if(num === undefined) return undefined;
    const minusN = factorOr0 ? factorOr0 : 0;
    return num - minusN;
}

export function plusIfDefined(num: number | undefined, factorOr0: number | undefined): number | undefined{
    if(num === undefined) return undefined;
    const plusN = factorOr0 ? factorOr0 : 0;
    return num + plusN;
}

export function plusIfBothDefined(num: number | undefined, factorOr0: number | undefined): number | undefined{
    if(num === undefined || factorOr0 === undefined) return undefined;
    const plusN = factorOr0 ? factorOr0 : 0;
    return num + plusN;
}