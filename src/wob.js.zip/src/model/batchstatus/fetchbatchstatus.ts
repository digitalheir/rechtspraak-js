import {ProcessingDoc, ProcessingDocWithTitle} from "./ProcessingDoc";
import {HTTP_ROOT_WOB} from "../lawly/WebsiteConstants";
import {ProcessingDocsStateByTitle} from "../../components/docs/overviewtables";
import {ProcessingDocsState} from "../ocrdocument/FetchDocumentContents";

const spaceyChars = /[_+-]+/g;

function determineTitle(doc: ProcessingDoc): ProcessingDocWithTitle {
    const fileName = doc.file.replace(/\.pdf\s*$/, "").trim();
    const prefixChip = fileName.match(/^((?:[a-z]|bijlagen?\b.?[0-9]*)?[0-9_-]+)\s*/);
    let chip: string | undefined = undefined;
    let title = fileName
    let prefix = ""
    if (prefixChip) {
        chip = prefixChip[1].replace(/[_-]+$/, "");
        title = fileName.substring(prefixChip[0].length);
    }
    const prefixStrMatch = title.match(/^(ICCb|wob\b.?\bverzoek\b.?inz\b.?)\b/);
    if (prefixStrMatch) {
        prefix = prefixStrMatch[0].replace(spaceyChars, " ").trim();
        title = title.substring(prefix.length);
    }
    return Object.assign(doc, {
        titlePrefix: prefix,
        title: title.replace(spaceyChars, " ").trim(),
        chip,
    });
}

function compareChips(a: ProcessingDocWithTitle, b: ProcessingDocWithTitle) {
    const chipA = a.chip?.toLowerCase();
    const chipB = b.chip?.toLowerCase();
    return chipA && chipB ? (chipA < chipB ? -1 : chipA > chipB ? 1 : 0) : (chipA ? 1 : (chipB ? -1 : 0));
}

function compareTitleAndChips(a: ProcessingDocWithTitle, b: ProcessingDocWithTitle) {
    const titleA = (a.titlePrefix + a.title).toLowerCase();
    const titleB = (b.titlePrefix + b.title).toLowerCase();
    return titleA < titleB ? -1 : (titleA > titleB ? 1 : compareChips(a, b));
}

function compareDocs(a: ProcessingDocWithTitle, b: ProcessingDocWithTitle) {
    const typeA = a.type;
    const typeB = b.type;
    return typeA ? (typeB ? typeA < typeB ? 1 : (typeA > typeB ? -1 : compareTitleAndChips(a, b)) : typeA ? -1 : typeB ? 1 : -1) : (typeB ? -1 : compareTitleAndChips(a, b));
}

function capitalize(phrase: string): string {
    return phrase.charAt(0).toUpperCase() + phrase.slice(1);
}

function normalizeToDossierTitle(str: string): string {
    //bijlagen besluit wob verzoek
    const dosTitle = str.trim()
        .replace(/^((?:bijlagen|bij|besluit|(documenten )?wob|verzoek|aangaande)[\s._-]*)+/i, "")
        .replace(/((?:deel|\(?\d+\)?)[\s._-]*)+$/i, "")
        .replace(/\(\s*\d+\s*\)\s*$/i, "")
        .trim()
    return capitalize(dosTitle);
}

function asArr(src: Map<string, ProcessingDocWithTitle[]>): Array<[string, ProcessingDocsState]> {
    const arr = new Array(src.size)
    for (const [title, results] of src.entries()) {
        // console.log(title)
        // console.log(results)
        arr.push([title, {results}]);
    }
    arr.sort(([title, _obj1], [title2, _obj2]) => {
        // console.log(title)
        // console.log(_obj1)
        const ttl1 = title.toLowerCase()
        const ttl2 = title2.toLowerCase()
        return ttl1 < ttl2 ? -1 : ttl1 > ttl2 ? 1 :  0;
    });
    return arr
}

export function groupByTitle(results?: ProcessingDocWithTitle[]): ProcessingDocsStateByTitle | undefined {
    if (results) {
        const multimap = new Map<string, ProcessingDocWithTitle[]>();
        results.forEach(
            (doc) => {
                const dosTitle = normalizeToDossierTitle(doc.title)
                const cur = multimap.get(dosTitle)
                if (cur) cur.push(doc); else multimap.set(dosTitle, [doc]);
            }
        )
        return {
            docs: asArr(multimap)  //Array<[string, ProcessingDocsState]>;
        }
    }
    return undefined
}

function urlProcessed(processed: string) {
    // We are now in archive mode, meaning that the processed/processing.json files are not live anymore, since we expect them to never update anymore
    // return `${API_WETTEN_WOB}/${processed}.json`;

    return `${HTTP_ROOT_WOB}/${processed}.json`;
}

export async function loadProcessing(processed: string): Promise<ProcessingDocWithTitle[]> {
    //const data = await fetch(`${API_ORIGIN}/v0/topstories.json`);
    //const items: any = asJson(data);
    //console.log(data)

    const data = await fetch(urlProcessed(processed));
    // throw Error("Fake error for "+processed);
    const docs = await data.json() as ProcessingDoc[];
    const items = docs.map(doc => determineTitle(doc));
    items.sort((a, b) => compareDocs(a, b));
    return items;

    // return await Promise.all(docs.map(
    //     (item: any) => {
    //         return {
    //             title: `${item}`
    //         }
    //     }
    //     //fetch(`${API_ORIGIN}/v0/item/${item}.json`).then(asJson)
    // ));
}
