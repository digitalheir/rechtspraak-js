
export interface FormattedString {
    type: string;
    text: string;
}
export interface ProcessingDoc {
    file: string;
    batchname: string;
    id: number;
    date: string;
    text: string | (string|FormattedString)[];
    type?: number;
}

export interface ChipPrefixTitle {
    chip?: string;
    title: string;
    titlePrefix: string;
}

export interface ProcessingDocWithTitle extends ProcessingDoc, ChipPrefixTitle {}