import debounce from "lodash.debounce";
import {DocSearchResult, DocSearchResults} from "./DocSearchResult";
import {API_WETTEN_WOB} from "../lawly/WebsiteConstants";
import {normalizeError} from "../util/errhelpers";

async function fetchSearchResults(query: string): Promise<DocSearchResult[]> {
    const data = await fetch(`${API_WETTEN_WOB}/search?q=${encodeURIComponent(query)}`);
    return await data.json() as DocSearchResult[];
    //return [{fileName: "dummy", title: "dummy", fullText: "dummy", tgmsg: 123,}];
}

const fetchResults = async (query: string, cb: (results: DocSearchResult[], err: Error | undefined) => void) => {
    try {
        const res = await fetchSearchResults(query);
        //throw("Synthetic error");
        cb(res, undefined);
    } catch (e) {
        //const result = e?.message; // error under useUnknownInCatchVariables
        cb([], normalizeError(e))
    }
};


export const debouncedFetchData = debounce((
    query: string,
    cb: (results: DocSearchResults) => void
) => {
    // if(!!window) {

        // @ts-ignore
        //const url = new URL(window.location);
        //url.searchParams.set('q', encodeURIComponent(query));

        // nav.push({
        //     q: query,
        // }, '', url);
    // }
    return fetchResults(query, (results, err) => {
        cb({ query, results, err });
    });
}, 50);


// export const useDebouncedSearch = (searchFunction: () => string) => {
// // Handle the input text state
// const [inputText, setInputText] = useState('');
// // Debounce the original search async function
// const debouncedSearchFunction = useConstant(() =>
//     AwesomeDebouncePromise(searchFunction, 300)
//      debounce(expensiveOperation, 100);
// );
//
// // The async callback is run each time the text changes,
// // but as the search function is debounced, it does not
// // fire a new request on each keystroke
// const searchResults = useAsync(
//     async () => {
//         if (inputText.length === 0) {
//             return [];
//         } else {
//             return debouncedSearchFunction(inputText);
//         }
//     },
//     [debouncedSearchFunction, inputText]
// );
//
// // Return everything needed for the hook consumer
// return {
//     inputText,
//     setInputText,
//     searchResults,
// };
// }
// ;