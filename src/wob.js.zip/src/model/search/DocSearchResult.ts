export interface DocSearchResult {
    fileName: string,
    title: string,
    batchname: string,
    tgmsg: any,
    fullText?: string,
    snippet?: string,
}

export interface DocSearchResults {
    query: string;
    results: DocSearchResult[];
    err?: Error;
}