import {ProcessedDocWithBatchId} from "../ocrdocument/FetchDocumentContents";


export const API_WETTEN_WOB = "https://wetten.lawreader.nl/wob";
export const HTTP_ROOT_WOB = "https://wob.lawreader.nl";

export function tgMsgUrl(tgMsgId: number | string): string {
    return `https://t.me/wobonderzoek/${tgMsgId}`;
}

export function urlToDocJson(batchid: string) {
    return `${HTTP_ROOT_WOB}/consolidated/${batchid}.json.gz`;
}

export function urlToConsolidatedDocJson(batchid: string) {
    return urlToDocJson(batchid);
}
export function urlToPdf(batchid: string) {
    return `${API_WETTEN_WOB}/pdf/${batchid}.pdf`;
}
