// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';
import TextPage from "../textpage";
import {HTTP_ROOT_WOB} from "../../model/lawly/WebsiteConstants";

const Dump: FunctionalComponent = () => {
    return (
        <TextPage><h2>Data dump</h2>
            <nav class={style.dldocs}>
                <a href={`${HTTP_ROOT_WOB}/dump.json.gz`} class={`button button-outline`}>Download
                    alle documenten (~250MB zip)</a>
            </nav>
            <section class={style.sctn}>
                <h3>Format</h3>
                <p class={style.para}>
                    De data-dump hierboven is een gegzipt JSON-bestand.
                    Uitgepakt is het bestand ongeveer 5 gigabyte groot, dus het is niet efficient om het hele bestand tegelijk te lezen.
                    Ik heb gezorgd dat elk document op een aparte regel staat, zodat de documenten regel voor regel in te lezen zijn.
                    Het bestand is valide JSON, dus het is ook mogelijk om een streaming JSON-parser te gebruiken zoals <a href="https://github.com/jimhigson/oboe.js/">Oboe.js</a>.
                </p>
                <p class={style.para}>
                    Een dump ziet er als volgt uit:
                </p>

                <pre class={style.marginbottom}><code dangerouslySetInnerHTML={{
                    __html: `{"dumpDate":"{YYYY}-{MM}-{DD}Z","docs":[
    {doc1},
    {doc2},
    ...,
    {docN}
]}`
                }}/></pre>
                <p class={style.para}>
                    Pseudocode om het bestand te lezen kan dus zijn:</p>
                    <pre class={style.marginbottom}><code dangerouslySetInnerHTML={{
                        __html: `with open('dump.json.gz') as file:
    for line in file:
       if !line.starts_with('{"dumpDate":') && !line.starts_with(']}'):
            process_ocr_doc(parse_json(line.remove_suffix(',')))`}}/></pre>


                <p class={style.para}>Elk document bevat een beetje metadata over het verwerkte bestand, en alle
                    ingelezen pagina's. Een ge-OCR'd document ziet er als volgt uit:</p>
                <pre class={style.marginbottom}><code dangerouslySetInnerHTML={{
                    __html: `interface OcrDoc {
    fileId: string
    batchId: string
    telegramMessage: TelegramMessage
    pages: OcrPage[]
}`
                }}/></pre>
                <dl>
                    <dt><code>fileId</code></dt>
                    <dd>Oorspronkelijke bestandsnaam van het gelezen PDF-document</dd>
                    <dt><code>batchId</code></dt>
                    <dd>Interne identifier gebaseerd op oorspronkelijke bestandsnaam; wordt door deze site gebruikt om
                        te navigeren
                        en bestanden terug te vinden
                    </dd>
                    <dt><code>telegramMessage</code></dt>
                    <dd>Telegrambericht waar de Klokkenluidersgroep dit betreffende document bespreken. Een hyperlink
                        naar het
                        bericht heeft de vorm <code
                            dangerouslySetInnerHTML={{__html: `https://t.me/wobonderzoek/{message_id}`}}/>
                    </dd>
                </dl>
            </section>
            <section class={style.sctn}>
                <h3>OCR-elementen</h3>
                <p class={style.para}>Een document is opgebroken in pagina's, die zijn opgebroken in tekstblokken, dan paragrafen,
                    dan woorden, en uiteindelijk symbolen (letters). Dit maakt een nogal complexe hiërarchie. Om gemakkelijker stukken tekst
                    uit te lezen bevat het
                    object <code>Page</code> een veld genaamd <code>text</code>, waar de geconsolideerde tekst van een hele pagina
                    in is opgeslagen. De
                    OCR-objecten zien er
                    ongeveer als volgt uit:</p>
                <pre><code dangerouslySetInnerHTML={{
                    __html: `interface OcrPage {
    pageNumber: number
    page?: Page
}

interface Page {
    text: string
    blocks: Block[]
    
    width: number
    height: number
    property?: TextProperty
    confidence?: number
}

interface Block {
    paragraphs: Paragraph[]
    
    blockType: string
    boundingBox: BoundingBox
    property?: TextProperty
    confidence?: number
}

interface Paragraph {
    words: Word[]
    
    boundingBox: BoundingBox
    property?: Property
    confidence: number
}

/** Detected bounds of a word */
interface Word {
    symbols: Symbol[]
    
    boundingBox: BoundingBox
    property?: TextProperty
    confidence: number
}

/** Represents letter or punctuation or line break, text is (almost) always 1 char long */
interface Symbol {
    text: string
    
    boundingBox?: BoundingBox
    property?: TextProperty
    confidence?: number
}

interface BoundingBox {
    normalizedVertices: NormalizedVertex[]
}

/** 0-1 position on the page. Multiply with Page.width/Page.height to get the absolute position */
interface NormalizedVertex {
    x?: number // undefined for 0
    y?: number // undefined for 0
}

interface Property {
    detectedLanguages: DetectedLanguage[]
}

interface DetectedLanguage {
    confidence?: number
    languageCode: string
}

interface TextProperty {
    detectedLanguages?: DetectedLanguage[]
    detectedBreak?: DetectedBreak
}

interface DetectedBreak {
    type?: BreakType
    isPrefix?: Boolean
}

enum BreakType {
    UNKNOWN = "UNKNOWN", // Unknown break label type
    SPACE = "SPACE", // Regular space
    SURE_SPACE = "SURE_SPACE", // Sure space (very wide)
    EOL_SURE_SPACE = "EOL_SURE_SPACE", // Line-wrapping break
    HYPHEN = "HYPHEN", // End-line hyphen that is not present in text; does not co-occur with SPACE, LEADER_SPACE, or LINE_BREAK
    LINE_BREAK = "LINE_BREAK", // Line break that ends a paragraph
}`
                }}>
</code></pre>
            </section>
        </TextPage>
    );
};
export default Dump;
