// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import {Link} from 'preact-router/match';
import style from './style.css';
import {StateUpdater} from "preact/hooks";
import {useBrowserHistory} from "../historyprovider";

interface SearchProps {
    onInput: (query: string) => any;
    onClear: () => any;
    query: string;
}

const Search: FunctionalComponent<SearchProps> = (
    {
        query,
        onInput,
        onClear,
    }
) => {
    const placeholder = "Typ hier om te zoeken"
        //const history = useBrowserHistory();
    return <div class={style.searchbar}>
        {query ?
            <button class={`button button-clear ${style.backbtn}`} onClick={_ => onClear()}>←</button> : ""}
        <form class={style.searchform} action="/" method="get">
            <label class={style.visuallyhidden} htmlFor="header-search">
                <span>{placeholder}</span>
            </label>
            <input
                class={style.textinput}
                value={query}
                onInput={e => onInput((e.target as HTMLInputElement)?.value || "")}
                type="text"
                id="header-search"
                placeholder={placeholder}
                name="s"
            />
            <button class={style.visuallyhidden} type="submit">Search</button>
        </form>
    </div>;
}

export default Search;