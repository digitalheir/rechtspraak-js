// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from "preact";
import {MutableRef, Ref, StateUpdater, useCallback, useEffect, useRef, useState} from "preact/hooks";
import {tgMsgUrl, urlToConsolidatedDocJson, urlToPdf} from "../../model/lawly/WebsiteConstants";
import {useMutationObservable} from "../utils/mutationobservable/mutationobservable";
import {ProcessedDocWithBatchId} from "../../model/ocrdocument/FetchDocumentContents";
import style from './style.css';

interface LinkButtonsProps {
    tgMsgId: number;
    batchid: string;
    channel?: string;
}

function isElement(x: Node): x is Element {
    return x.nodeType === Node.ELEMENT_NODE
}

function createMutationListener(setIdOfAddedPost: StateUpdater<string>): (mutationList: MutationRecord[]) => any {
    // console.log("creating")
    return (mutationList: MutationRecord[]) => {
        console.log(mutationList)
        for (let mutation of mutationList) {
            switch (mutation.type) {
                case "childList":
                    const addedNodes = mutation.addedNodes;
                    for (let ix = 0; ix < addedNodes.length; ix++) {
                        const node = addedNodes[ix];
                        if (isElement(node)) {
                            console.log(node.id)
                            const m = node.id.match(/telegram-(?:post|discussion)-[a-z]+-(\d+)(-\d+)?/i)
                            if (m) {
                                // Embedded discussion was added to DOM //console.log(m[1])
                                setIdOfAddedPost(m[1])
                            }
                        } // else console.log(node)
                    }
            }
        }
    }
}

const removeScript = (parent: Element | null, id: string) => {
    if (parent && id) {
        const script = document.getElementById(id);
        if (script) parent.removeChild(script);
    }
};

const addScript = (
    parent: Element,
    tgMsgId: number,
    onLoad: (() => any) | undefined,
    channel: string = "wobonderzoek",// https://t.me/toncoin/412
) => {
    const id = `tg-script-${tgMsgId}`;
    const existing = document.getElementById(id);
    if (existing) {
        return existing;
    } else {
        const script = document.createElement("script");
        script.src = `https://telegram.org/js/telegram-widget.js?19`;
        script.id = id;
        script.async = true;
        script.onload = () => {
            if (onLoad) onLoad();
        };
        script.setAttribute("data-userpic", `false`)
        // script.setAttribute("data-height", `320`)
        script.setAttribute("data-height", `auto`)
        script.setAttribute("data-telegram-discussion", `${channel}/${tgMsgId}`)
        parent.appendChild(script);
        return script;
    }
};

const LinkButtons: FunctionalComponent<LinkButtonsProps> = ({tgMsgId, batchid, channel}) => {
    const listRef: MutableRef<HTMLDivElement | null> = useRef() as MutableRef<HTMLDivElement | null>; // todo remove cast when fixed https://github.com/n8tb1t/use-scroll-position/issues/41
    const [postLoaded, setIdOfAddedPost] = useState("");
    //useMutationObservable(listRef.current, onListMutation);
    const [observer, setObserver] = useState<MutationObserver | undefined>(undefined);
    useEffect(() => {
        return () => observer?.disconnect()
    });

    const msgIdAsStr = `${tgMsgId}`;
    return <div id={`doc-${msgIdAsStr}`} ref={node => {
        removeScript(listRef.current, postLoaded)
        if (node && node !== listRef.current) {
            observer?.disconnect();
            listRef.current = node;
            const obs = new MutationObserver(createMutationListener(setIdOfAddedPost));
            setObserver(obs);
            try {
                obs.observe(node, {attributes: false, childList: true, subtree: true});
            } catch (e) {
                console.error(e);
            }
            addScript(node, tgMsgId, () => {
            }, channel || "wobonderzoek");
            //console.log(`[${docdata.tgMsgId}] script loaded!`),
        }
    }}>
        <div class={style.navmargins}>
        <a class="button" href={urlToConsolidatedDocJson(batchid)}>Download OCR-data (JSON)</a> <a
        class="button" href={urlToPdf(batchid)}>Download PDF</a><br/>
        <a
            class={`button button-outline ${style.opentg}`}
            href={tgMsgUrl(msgIdAsStr)}>Open Telegram-discussie</a>
        </div>
    </div>;
}
//hidden={postLoaded === msgIdAsStr ? true : undefined}


// telegram-post-wobonderzoek-138
// data-width="100%"

// interface TgPost {
//     tgMsgId: number;
// }


export default LinkButtons;