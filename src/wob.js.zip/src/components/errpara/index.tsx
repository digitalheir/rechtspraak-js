// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';

export interface ErrParaProps {
    what: string;
    err?: Error;
}
//<{  }>
const ErrPara: FunctionalComponent<ErrParaProps> = ({what, err}) => {
    return <p class={style.err}>Kon {what} niet laden: {err?.message}. Laat de beheerder weten dat deze
        fout plaatsvond.</p>;
}

export default ErrPara;
