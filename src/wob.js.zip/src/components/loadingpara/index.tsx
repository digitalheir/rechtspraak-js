// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';

export interface LoadingProps {
    // what: string;
    // err?: Error;
    center?: boolean;
}
//<{  }>
const LoadingPara: FunctionalComponent<LoadingProps> = ({center}) => {
    return <p class={`${style.loading} ${center ? style.centered : ""}`}>Laden…</p>;
}

export default LoadingPara;
