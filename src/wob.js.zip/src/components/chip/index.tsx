// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';

export interface ChipProps {
    content: string;
    darker?: boolean;
}
//<{  }>
const Chip: FunctionalComponent<ChipProps> = ({content, darker}) => {
    return <code class={`${style.codechip} ${darker ? style.darker : ""}`}>{content}</code>;
    //<div class={style.chip}></div>;
}

export default Chip;
