import {createBrowserHistory, createMemoryHistory} from "history";
import {CustomHistory} from "preact-router";
import {createContext, h, Provider} from "preact";
import {useContext} from "preact/compat";

export const browserHistory = (typeof window !== "undefined" ? createBrowserHistory() : createMemoryHistory() ) as unknown as CustomHistory;
const HistoryContext = createContext(browserHistory);

const HistoryProvider: Provider<CustomHistory> = ({ value, children}) => {
    return <HistoryContext.Provider value={ value }>
        {children}
    </HistoryContext.Provider>
}
export const useBrowserHistory = () => useContext(HistoryContext);

export default HistoryProvider;
