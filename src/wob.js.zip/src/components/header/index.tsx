// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import {Link} from 'preact-router/match';
import style from './style.css';

const Header: FunctionalComponent = () => {
    return (
        <header class={style.header}>
                <Link activeClassName={style.active} href="/">
                    <h1 class={style.appbartitle}>WOB-documenten</h1>
                </Link>
            <nav>
                <Link activeClassName={style.active} href="/dump">
                    Data dump
                </Link>
                {/*<Link activeClassName={style.active} href="/over">Over mij</Link>*/}
            </nav>
        </header>
    );
};
// <Link activeClassName={style.active} href="/">
//     Home
// </Link>
// <Link activeClassName={style.active} href="/profile">
//     Me
// </Link>
// <Link activeClassName={style.active} href="/profile/john">
//     John
// </Link>

export default Header;
