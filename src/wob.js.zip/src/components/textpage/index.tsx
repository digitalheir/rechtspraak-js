// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import {useEffect, useState} from 'preact/hooks';
import style from './style.css';

interface TextPageProps {

}

const TextPage: FunctionalComponent<TextPageProps> = ({children}) => {
    //const [time, setTime] = useState<number>(Date.now());
    //const [count, setCount] = useState<number>(0);

    // gets called when this route is navigated to
    // useEffect(() => {
    //     const timer = window.setInterval(() => setTime(Date.now()), 1000);
    //     // gets called just before navigating away from the route
    //     return (): void => { clearInterval(timer); };
    // }, []);
    //
    // // update the current time
    // const increment = (): void => {
    //     setCount(count + 1);
    // };

    return (
        <div class={style.content}>{children}</div>
    );
};

export default TextPage;
