// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';
import {PlainTextState} from "../../../model/ocrdocument/PlainTextState";
import LoadingPara from "../../loadingpara";


interface PlainTextProps {
    plainText?: PlainTextState;
}

const DocPlainText: FunctionalComponent<PlainTextProps> = ({plainText}: PlainTextProps) => {
    return plainText ? <div class={style.docplaintext}>{plainText.fullText.split("\n").map(line => {
            return <span>{line}<br/></span>;
        }
    )}</div> : <LoadingPara center={true}/>;
}


export default DocPlainText;
