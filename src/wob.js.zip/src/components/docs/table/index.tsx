// noinspection HtmlUnknownAttribute,HtmlUnknownTarget

import {FunctionalComponent, h} from 'preact';
import style from './style.css';
import {ProcessingDocWithTitle} from "../../../model/batchstatus/ProcessingDoc";
import {Link} from 'preact-router/match';
import {tgMsgUrl, urlToDocJson, urlToPdf} from "../../../model/lawly/WebsiteConstants";
import DocsRowWithTitle from "../docsrowtitle";

interface DocsTableProps {
    docs: ProcessingDocWithTitle[];
    processed?: boolean;
    showStatusColumn?: boolean;
    isClosed?: boolean;
}

const DocsTable: FunctionalComponent<DocsTableProps> = (
    {
        isClosed,
        showStatusColumn,
        docs,
        processed,
    }
) => {
        // <div class={style.subsection}></div>
    return <div class={`docsholder ${isClosed ? style.closed : ""}`}>
        <table class={`${style.docstable}`}>
            <thead>
            <tr>
                {
                    showStatusColumn ? <th class={processed ? style.colstatus : ""}>
                        Status
                    </th> : null
                }
                <th>
                    Bestand
                </th>
                <th>
                    Telegram-discussie
                </th>
                {
                    processed ?
                        <th class={style.thdownloadjson}>
                            JSON
                        </th> : null
                }
                {
                    processed ?
                        <th class={style.thdownloadpdf}>
                            PDF
                        </th> : null
                }
            </tr>
            </thead>
            <tbody>
            {
                docs.map((doc: ProcessingDocWithTitle) => {
                    // doc.file
                    // .replace(/[_+-]+/g, " ")
                    // .replace(/\.pdf\s*$/g, "")
                    // .trim();
                    const tgMsgId = doc.id;
                    return <tr key={doc.batchname}>
                        {
                            showStatusColumn ? <td class={`${style.status} ${processed ? style.colstatus : ""}`}>
                                {
                                    !doc.type ? "✅" : doc.type == -1 ? "📫" : "⏳"
                                }
                                <span
                                    class={`${!doc.type ? style.done : doc.type == -1 ? style.queued : style.processing}`}>{
                                    !doc.type ? ""/*"\u00A0Verwerkt"*/ : doc.type == -1 ? "\u00A0In wachtrij" : " Verwerken…"
                                }</span>
                            </td> : null
                        }
                        <td>
                            {
                                !doc.type ? <Link
                                        href={`/doc?batchid=${encodeURIComponent(doc.batchname)}`}><DocsRowWithTitle
                                        title={doc} msgText={doc.text}/></Link> :
                                    <DocsRowWithTitle title={doc} msgText={doc.text}/>
                            }
                        </td>
                        <td>
                            <a href={tgMsgUrl(tgMsgId)}>
                                @wob/{tgMsgId}
                            </a>
                        </td>
                        {
                            processed ?
                                <td class={style.btndownloadcell}>
                                    <a class={`button button-clear ${style.btndownload}`}
                                       href={urlToDocJson(doc.batchname)}>💾</a>
                                </td> : ""
                        }
                        {
                            processed ?
                                <td class={style.btndownloadcell}>
                                    <a class={``}
                                       href={urlToPdf(doc.batchname)}><img
                                        class={style.pdficon}
                                        alt="PDF"
                                        src="/assets/img/pdf_file.svg"/></a>
                                </td> : ""
                        }
                    </tr>;
                })
            }
            </tbody>
        </table>
    </div>
}

export default DocsTable;
