// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';
import {ProcessingDocsState} from "../../../model/ocrdocument/FetchDocumentContents";
import ErrPara from "../../errpara";
import DocsTable from "../table";
import LoadingPara from "../../loadingpara";
import {useState} from "preact/hooks";

export interface ProcessingDocsStateByTitle {
    err?: Error;
    loading?: boolean;
    docs: Array<[string, ProcessingDocsState]>;
}

export interface TableProps {
    processed: ProcessingDocsStateByTitle | undefined;
    processing: ProcessingDocsState | undefined;
}

interface SubSecProps {
    title: string,
    dossier: ProcessingDocsState,
}

const SubSection: FunctionalComponent<SubSecProps> = ({title, dossier}) => {
    const [isClosed, setOpen] = useState(true);
    return <section>
        <h3
            class={`${style.dossiertitle} ${isClosed ? style.closed : ""}`}
            onClick={_ => setOpen(!isClosed)}
        >{title}<br/>
            <span class={style.filecount}>{dossier.results.length} bestanden</span></h3>


        <DocsTable
            isClosed={isClosed}
            docs={dossier.results}
            processed={true}
            showStatusColumn={false}/>
    </section>;
}
// No search query, so show all docs grouped by loading status
const NoQueryYet: FunctionalComponent<TableProps> = (
    {
        processed,
        processing,
    }) => {
    return <div>
        <section>
            <h2 class={style.docstabletitle}>Doorzoekbaar</h2>
            {processed ? processed.err ? <ErrPara what={"documenten"} err={processed.err}/> : <ul>
                {
                    processed.docs.map(([title, dossier]) =>
                        <SubSection title={title} dossier={dossier}/>
                    )
                }
            </ul> : <LoadingPara/>}
        </section>
    </div>;
        // <section><h2 class={style.docstabletitle}>Niet verwerkt</h2>
        //     <p>
        //         Deze documenten zijn dubbel geüploadet, en worden daarom maar 1 keer verwerkt
        //     </p>
        //     {processing ? processing.err ? <ErrPara what={"documenten"} err={processing.err}/> : processing.results.length ? <ul>
        //         <DocsTable docs={processing.results}/>
        //     </ul> : <div>✅ Alle documenten zijn verwerkt!</div> : <LoadingPara/>}</section>
}

export default NoQueryYet;
