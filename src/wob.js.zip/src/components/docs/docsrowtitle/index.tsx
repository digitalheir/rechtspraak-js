import {ChipPrefixTitle, FormattedString, ProcessingDocWithTitle} from "../../../model/batchstatus/ProcessingDoc";
import {FunctionalComponent, h} from "preact";
import Chip from "../../chip";
import style from './style.css';

interface StyledTextProps {
    text: FormattedString;
}

function getClassForStyleType(tp: string) {
    switch(tp) {
        case "underline":
            return style.underline;
        case "bold":
            return style.bold;
        case "mention":
            return style.mention; // todo make it a url!
        default:
            console.log(tp);
            return tp;
    }
}

const StyledText: FunctionalComponent<StyledTextProps> = ({text}) => {
    // todo also process mentions!
    const tp = text.type;
    return <span class={getClassForStyleType(tp)}>{text.text}</span>;
}

interface DocsRowWithTitleProps {
    title: ChipPrefixTitle;
    msgText: string | (string|FormattedString)[];
}

interface MsgText {
    text: string | (string | FormattedString)[];
}

const RenderMsgText: FunctionalComponent<MsgText> = ({text}) => {
    if (typeof text === "string") {
        return <p>{text}</p>;
    } else {
        // (string|FormattedString)[]
        return <div>{
            text.map(txt => typeof txt === "string" ? txt : <StyledText text={txt}/>)
        }</div>;
    }
}

interface DocsTitleProps {
    // chip?: string;
    title: string;
    titlePrefix: string;
}

const DocTitle: FunctionalComponent<DocsTitleProps> = ({titlePrefix, title}) => {
    return titlePrefix ? <span><Chip content={titlePrefix} darker={true}/> {title}</span> :
        <span>{title}</span>;
}

function isBlank(msgText: string): boolean {
    return !!msgText.match(/^\s*$/)
}

function textIsDefined(msgText: string | (string | FormattedString)[]): boolean {
    return !!(msgText && ((typeof msgText === "string" && !isBlank(msgText)) || msgText.length));
}

const DocsRowWithTitle: FunctionalComponent<DocsRowWithTitleProps> = ({title, msgText}) => {
    const prettyName = title.chip ? <div class={style.title}><Chip content={title.chip}/> {title.title}</div> :
        <div class={style.title}><DocTitle {...title}/></div>;
    return <div>
        {prettyName}
        {textIsDefined(msgText) ?
            <div class={style.summary}>
                <RenderMsgText text={msgText}/>
            </div> : null
        }
    </div>;
}

export default DocsRowWithTitle;
