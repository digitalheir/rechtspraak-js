// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';

import {Page, ReconstructedDoc, VisionBlock} from "../../../model/ocrdocument/ReconstructedDoc";
import {appendStr} from "../../../model/util/stringutils";
import {minus, minusIfDefined, plusIfDefined, times, timesIfDefined} from "../../../model/util/numberutils";
import {largestOf, smallestOf} from "../../../model/ocrdocument/sizehelpers";
import ReconstructedParagraph from "../docreconstructedparagraph";
import ScrollToTop from "../../scrolltotop";

interface InnerPgProps {
    innerPage: Page;
}
const paddingHorizontal = 20;
const paddingVertical = 20;
const InnerPg: FunctionalComponent<InnerPgProps> = ({innerPage}) => {
            const height0 = innerPage.height;
            const width0 = innerPage.width;

            const blocks = innerPage.blocks;
            const whitespaceLeftPreFactor = timesIfDefined(width0, smallestOf(blocks, b => b.x));
            const whitespaceRightPreFactor = minusIfDefined(width0, timesIfDefined(width0, largestOf(blocks, b => b.x)));
            //console.log(whitespaceRight);
            const whitespaceTopPreFactor = timesIfDefined(height0, smallestOf(blocks, b => b.y));
            const whitespaceBottomPreFactor = minusIfDefined(height0, timesIfDefined(height0, largestOf(blocks, b => b.y)));

            const widthWithoutWhitespace = minusIfDefined(width0, plusIfDefined(whitespaceLeftPreFactor, whitespaceRightPreFactor))
            const heightWithoutWhitespace = minusIfDefined(height0, plusIfDefined(whitespaceTopPreFactor, whitespaceBottomPreFactor))
            const multiplicationFactor =
                heightWithoutWhitespace && widthWithoutWhitespace
                && heightWithoutWhitespace > 200 && widthWithoutWhitespace > 200
                    //&& heightWithoutWhitespace > widthWithoutWhitespace
                    ? (widthWithoutWhitespace < 800 ? 800 / widthWithoutWhitespace : 2) : 1.5;

            const whitespaceLeft = timesIfDefined(multiplicationFactor, whitespaceLeftPreFactor)
            const whitespaceRight = timesIfDefined(multiplicationFactor, whitespaceRightPreFactor)
            const height = times(multiplicationFactor, height0);
            const width = times(multiplicationFactor, width0);
            const whitespaceTop = times(multiplicationFactor, whitespaceTopPreFactor);
            const whitespaceBottom = times(multiplicationFactor, whitespaceBottomPreFactor);

            return <InnerPage {...{
                blocks,
                width,
                height,
                whitespaceLeft,
                whitespaceTop,
                whitespaceRight,
                whitespaceBottom,
                paddingHorizontal,
                paddingVertical,
            }}/>;
        }
interface InnerPageProps {
    blocks: VisionBlock[];
    width: number | undefined;
    height: number | undefined;
    whitespaceLeft: number | undefined;
    whitespaceTop: number | undefined;
    whitespaceRight: number | undefined;
    whitespaceBottom: number | undefined;
    paddingHorizontal: number;
    paddingVertical: number;
}
const InnerPage: FunctionalComponent<InnerPageProps> = ({
                                                            blocks,
                                                            width,
                                                            height,
                                                            whitespaceLeft,
                                                            whitespaceTop,
                                                            whitespaceRight,
                                                            whitespaceBottom,
                                                            paddingHorizontal,
                                                            paddingVertical,
}) => {
    return <div class={style.pageinner} style={
        {
            width: width ? appendStr(
                minus(minus(width, whitespaceLeft), minusIfDefined(whitespaceRight, paddingHorizontal * 2)), "px") : undefined,
            height: height ? appendStr(
                minus(minus(height, whitespaceTop), minusIfDefined(whitespaceBottom, paddingVertical * 2)), "px") : undefined,
        }
    }>
        {
            blocks.map(block => {
                    // const blockCoordinates = block.boundingBox.normalizedVertices;
                    // const blockWidth = determineLargestDifferenceAsPx(blockCoordinates, width, (v) => v.x);
                    // const blockHeight = determineLargestDifferenceAsPx(blockCoordinates, height, (v) => v.y);

                    return <div class={style.block} style={{
                        // width: blockWidth ? `${blockWidth}px` : undefined,
                        // height: blockHeight ? `${blockHeight}px` : undefined,
                    }}>{
                        block.paragraphs.map(paragraph => {
                                return <ReconstructedParagraph {...{
                                    blocks,
                                    paddingHorizontal,
                                    paddingVertical,
                                    paragraph,
                                    width,
                                    height,
                                    whitespaceLeft,
                                    whitespaceTop,
                                }}/>;
                            }
                        )
                    }</div>;
                }
            )
        }
    </div>;
}
interface ReconstructedProps {
    doc: ReconstructedDoc;
}

interface PageProps {
    page: number | undefined;
}


const PrevPage: FunctionalComponent<PageProps> = ({page}) => {
    return <a href={`#page-${minusIfDefined(page, 1)}`} class={style.pagebtn} title="Vorige pagina">⬅</a>
}
const NextPage: FunctionalComponent<PageProps> = ({page}) => {
    return <a href={`#page-${plusIfDefined(page, 1)}`} class={style.pagebtn} title="Volgende pagina">➡</a>
}
const DocReconstructed: FunctionalComponent<ReconstructedProps> = ({doc}) => {
                    const allPages = doc.pages;
                    //console.log(ix)
    return <div class={style.docprocessing}>{
        doc.pages.map((page, ix) => {
                    const pageNr = page.pageNumber;
                    const innerPage = page.page;
            return <div class={`${style.pagewrapper}`}>
                    <div id={`page-${pageNr}`}>
                        <hr class={style.divider}/>
                        <header class={style.pagenr}>
                            <div class={style.pagecontrol}>{ix > 0 ?
                                <PrevPage page={pageNr}/> : ""}<span
                                class={style.pagetitle}>Pagina {pageNr}</span>{ix < allPages.length - 1 ?
                                <NextPage page={pageNr}/> : ""}</div>
                            <ScrollToTop/></header>
                        {
                            // <hr class={style.divider}/>
                            innerPage ? <InnerPg innerPage={innerPage}/>: <p class={style.notextfound}>Geen tekst gevonden</p>
                        }
                    </div>
        </div>;})
    }</div>;
}

export default DocReconstructed;
