// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';

import {
    ParagraphBlock,
    WordBox
} from "../../../model/ocrdocument/ReconstructedDoc";
import {appendPx} from "../../../model/util/stringutils";
import {minusIfDefined, plusIfDefined} from "../../../model/util/numberutils";
import {
    cssSmallestCoordinateScaled,
    determineAverageFontSize,
    determineLargestDifferenceAsPx,
} from "../../../model/ocrdocument/sizehelpers";
import {joinString} from "../../../model/ocrdocument/reconstructedparagraph";

interface ReconstructedParagraphProps {
    paragraph: ParagraphBlock;
    paddingHorizontal: number;
    paddingVertical: number;
    width: number | undefined;
    height: number | undefined;
    whitespaceLeft: number | undefined;
    whitespaceTop: number | undefined;
}

const ReconstructedParagraph: FunctionalComponent<ReconstructedParagraphProps> = (
    {
        paddingHorizontal,
        paddingVertical,
        paragraph,
        width, height,
        whitespaceLeft, whitespaceTop,
    }) => {
    const vertices = paragraph?.boundingBox?.normalizedVertices;
    const xLeft = cssSmallestCoordinateScaled(vertices, width, (v) => v.x);
    const yTop = cssSmallestCoordinateScaled(vertices, height, (v) => v.y);

    const paraHeight = determineLargestDifferenceAsPx(vertices, height, (v) => v.y);
    const paraWidth = determineLargestDifferenceAsPx(vertices, width, (v) => v.x);

    return <p class={style.para} style={
        {
            //position: "absolute",
            left: appendPx(plusIfDefined(minusIfDefined(xLeft, whitespaceLeft), paddingHorizontal)),
            top: appendPx(plusIfDefined(minusIfDefined(yTop, whitespaceTop), paddingVertical)),
            height: typeof paraHeight === "number" ? `${paraHeight + 24}px` : undefined,
            width: typeof paraWidth === "number" ? `${paraWidth + 2}px` : undefined,
            fontSize: determineAverageFontSize(paragraph, height),
        }
    }>{
        //paragraph.words.map((word: WordBox) => {
        paragraph.words.flatMap((word: WordBox) => {
            const entireString = joinString(word);
            return entireString.map(token => typeof token === "string" ? token :
                <br/>);
            // // const verticesWord = word.boundingBox?.normalizedVertices;
            // // const availableSpace = determineSmallestHeight(verticesWord, height);
            // return <span class={style.word} style={
            //     {
            //         // fontSize: typeof availableSpace === "number" ? `${roundTo100s(determineSizeFactor(word) * availableSpace)}px` : undefined
            //     }
            // }>{
            //     entireString.map(token => typeof token === "string" ? token : <br/>)
            //     // <span class={style.wordInner}>{entireString.map(token => typeof token === "string" ? token : <br/>)}</span>
            //
            //     // word.symbols.map(symbol => {
            //     //     return <span class={style.sym}>{
            //     //         symbol.text
            //     //     }</span>
            //     // })
            // }</span>
        })
    }</p>;
}

export default ReconstructedParagraph;
