// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';

function smoothScrolToTop() {
    if (!!window) window.scrollTo({top: 0, behavior: "smooth"});
}

//<{  }>
const ScrollToTop: FunctionalComponent = () => {
    return <button onClick={smoothScrolToTop} class={`${style.scrollbtn} button-outline`} title="Scroll naar boven">⬆</button>;
}

export default ScrollToTop;
