// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';
import {StateUpdater, useEffect, useState} from "preact/hooks";
import {DocSearchResult, DocSearchResults} from "../../model/search/DocSearchResult";
import {debouncedFetchData} from "../../model/search/SearchHelpers";
import {Link} from 'preact-router/match';
import ErrPara from "../errpara";
import LoadingPara from "../loadingpara";

interface SearchResultsProps {
    query: string;
    queryField: string;
    loading: boolean;
    setLoading: StateUpdater<boolean>;
}


const SearchResults: FunctionalComponent<SearchResultsProps> = ({query, loading, setLoading}) => {
    const [results, setResults] = useState<DocSearchResults>({query: "", results: []});
    useEffect(() => {
            let isMounted = true;
            if (query) debouncedFetchData(query, (res) => {
                if(isMounted) setResults(res);
                // console.log("debouncedFetchData:setLoading(false)");
                setLoading(false);
            });
            return () => { isMounted = false }; // cleanup toggles value, if unmounted
        },
        [ query ],
    );

    const err = results?.err;
    return <div class={style.searchresults}>{err ? <ErrPara what={"zoekresultaten"} err={err}/> : ""}
        {results.results?.length === 0 ? loading ? <LoadingPara center={true}/> :
                <p class={style.noresults}>Geen resultaten gevonden.</p> :
            <ol class={`${style.results} ${!loading && results.query === query ? style.done : style.stale}`}>{
                results.results.map((e: DocSearchResult) => {
                        const snippet = e.snippet;
                        return <Link href={"/doc?batchid=" + encodeURIComponent(e.batchname)}>
                            <li class={style.searchresult}>
                                <h2 class={style.title}>{e.title}</h2>
                                <p class={style.snippet} dangerouslySetInnerHTML={{
                                    __html: snippet ? snippet : makeSnippet(e.fullText || "…"),
                                }}/>
                            </li>
                        </Link>;
                    }
                )}
            </ol>}</div>;

    function makeSnippet(txt: string): string {
        if (txt.length > 50) {
            return `${txt.substring(0, 500)}…`;
        } else {
            return txt;
        }
    }
}


export default SearchResults;
