import {createContext, FunctionalComponent, h, Provider} from "preact";
import {CustomHistory, Route, Router, RouterOnChangeArgs} from "preact-router";
//import {BrowserRouter} from "preact-router-dom";

import Home from '../routes/home';
import NotFoundPage from '../routes/notfound';
import Header from './header';
import Over from "../routes/over";
import Doc from "../routes/doc";
import HistoryProvider, {browserHistory} from "./historyprovider";
import {StateUpdater, useState} from "preact/hooks";
import Dump from "./dump";
import TestDoc from "../routes/test";

function handleUrlChangeQuery<RouteParams extends Record<string, string | undefined> | null = Record<string, string | undefined> | null>(setQuery: StateUpdater<string>) {
    return (e: RouterOnChangeArgs<RouteParams>) => {
        const matches = e.matches;
        //console.log(e)
        if(e) {
            switch (e.path) {
                case "/":
                    setQuery(matches?.q || "");
                    break;
            }
        }
    };
}
function handleUrlChange() {

}
const App: FunctionalComponent = () => {
    const [queryField, setQueryField] = useState("");
    return (
        <div id="preact_root">
            <HistoryProvider value={browserHistory}>
                <Header/>
                <Router history={browserHistory} onChange={handleUrlChangeQuery(setQueryField)}>
                    <Route path="/dump/" component={Dump}/>
                    <Route path="/over/" component={Over}/>
                    <Route path="/doc/" component={Doc}/>
                    <Route path="/test/" component={TestDoc}/>
                    <Route path="/" component={Home} {...{queryField, setQueryField}}/>
                    <NotFoundPage default/>
                </Router>
            </HistoryProvider>
        </div>
    );
};
// <Route path="/profile/" component={Profile} user="me" />
// <Route path="/profile/:user" component={Profile} />

export default App;
