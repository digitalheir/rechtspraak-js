import {useEffect, useState} from "preact/hooks";
import debounce from "lodash.debounce";

const DEFAULT_OPTIONS = {
    config: {attributes: true, childList: true, subtree: true},
};

/**
 * This custom hooks abstracts the usage of the Mutation Observer with React components.
 * Watch for changes being made to the DOM tree and trigger a custom callback.
 * @param {Element} targetEl DOM element to be observed
 * @param {Function} cb callback that will run when there's a change in targetEl or any
 * child element (depending on the provided options)
 * @param {Object} options
 * @param {Object} options.config check \[options\](https://developer.mozilla.org/en-US/docs/Web/API/MutationObserver/observe)
 * @param {number} [options.debounceTime=0] a number that represents the amount of time in ms
 * that you which to debounce the call to the provided callback function
 */
export function useMutationObservable(
    targetEl: Element | null,
    cb: (x: MutationRecord[]) => any,
    options: any = DEFAULT_OPTIONS,
) {
    const [observer, setObserver] = useState<MutationObserver | undefined>(undefined);
    useEffect(() => {
        if (!cb || typeof cb !== "function") {
            console.warn(`You must provide a valid callback function, instead you've provided ${cb}`);
        } else {
            const {debounceTime} = options;
            const obs = new MutationObserver(/*debounceTime > 0 ? debounce(cb, debounceTime) : */cb);
            setObserver(obs);
        }
    }, [cb, options, setObserver]);

    useEffect(() => {
        if (!observer) return;
        else if (!targetEl) console.warn(`You must provide a valid DOM element to observe, instead you've provided ${targetEl}`);
        else {
            const {config} = options;
            try {
                observer.observe(targetEl, config);
            } catch (e) {
                console.error(e);
            }
            return () => observer?.disconnect();
        }
    }, [observer, targetEl, options]);
}