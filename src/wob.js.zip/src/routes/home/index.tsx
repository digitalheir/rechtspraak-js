// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';
import {StateUpdater, useEffect, useState} from "preact/hooks";
import SearchResults from "../../components/searchresults";
import {groupByTitle, loadProcessing} from "../../model/batchstatus/fetchbatchstatus";
import Search from "../../components/search";
import {normalizeError} from "../../model/util/errhelpers";
import {ProcessingDocsState} from "../../model/ocrdocument/FetchDocumentContents";
import NoQueryYet, {ProcessingDocsStateByTitle} from "../../components/docs/overviewtables";
import {useBrowserHistory} from "../../components/historyprovider";
import debounce from "lodash.debounce";
import {CustomHistory} from "preact-router";


interface HomeProps {
    q: string;
    queryField: string;
    setQueryField: StateUpdater<string>;
}

async function asJson(r: Response): Promise<any> {
    return await r.json();
}

// <label htmlFor="header-search">
//     <span class="visually-hidden">Doorzoek WOB-documenten</span>
// </label>
//value={searchQuery}            onInput={e => setSearchQuery(e.target.value)}
const filterPosts = (posts: string[], query: string) => {
    if (!query) {
        return posts;
    }
    return posts.filter((post) => {
        const postName = post.toLowerCase(); // .name
        return postName.includes(query);
    });
};

function determineQueryFromUrl() {
    if (typeof window !== "undefined") {
        const {search} = window.location;
        return new URLSearchParams(search).get('s');
    } else {
        return undefined;
    }
}

async function setUrlParam(history: CustomHistory, query: string) {
    //console.log(`Set q = ${query}`);
    if (history?.push) history.push(`.?q=${encodeURIComponent(query)}`);
}

const debounceSetQuery = debounce((history: CustomHistory, queryField: string, newQuery: string) => {
    //console.log(`New query: ${queryField} ('${newQuery}')`);
    return setUrlParam(history, queryField);
}, 500);

function normalizeQuery(query: string) {
    return query.trim();
}

//export default Search;
const Home: FunctionalComponent<HomeProps> = ({queryField, setQueryField, q}) => {
    const queryFromUrl = q || determineQueryFromUrl();

    const query = queryFromUrl || ""

    const [loading, setLoading] = useState<boolean>(true);

    // const [time, setTime] = useState<number>(Date.now());
    const [processing, setProcessing] = useState<ProcessingDocsState | undefined>(undefined);
    const [processed, setProcessed] = useState<ProcessingDocsStateByTitle | undefined>(undefined);
    //const history = useHistory

    const filteredPosts = [];//filterPosts(posts, query);

    // gets called when this route is navigated to
    useEffect(() => {
        // const timer = window.setInterval(() => {
        //     const now = Date.now();
        //     //console.log(now);
        //     setTime(now)
        // }, 1000);

        loadProcessing("processing").then(results => setProcessing({results})).catch(e => {
            setProcessing({results: [], err: normalizeError(e)})
        });
        loadProcessing("processed").then(results => setProcessed(groupByTitle(results))).catch(e => {
            setProcessed({docs: [], err: normalizeError(e)})
        });

        // // gets called just before navigating away from the route
        // return (): void => {
        //     clearInterval(timer);
        // };
    }, []);

    // const corsHeaders = {
    //     "Access-Control-Allow-Methods": "GET,HEAD,POST,OPTIONS",   "Access-Control-Max-Age": "86400",
    //     //"Access-Control-Allow-Origin": "*"
    //     "Access-Control-Allow-Origin": "https://digitalheir.github.io"
    // };
    const history = useBrowserHistory();
    //const navigate = (window !== undefined && document !== undefined) ? useNavigate() : undefined;

    const actualQuery = normalizeQuery(query);
    return (
        <div class={style.home}>
            <section>
                {
                    queryField ? "" : <h2>Zoeken</h2>
                }
                <Search query={queryField}
                        onClear={() => {
                            //console.log("onClear:setLoading(false)");
                            setLoading(false);
                            setQueryField("");
                            if (history?.push) history.push("/");
                        }
                        }
                        onInput={(str) => {
                            setQueryField(str);
                            const newQuery = normalizeQuery(str);
                            if (newQuery !== actualQuery) {
                                //console.log("onInput:setLoading(true)");
                                setLoading(true);
                                debounceSetQuery(history, str, newQuery);
                                // } else {
                                //     console.log(`${newQuery} !== ${actualQuery}`)
                            }
                        }}/>
                {
                    !!queryField.trim() ? <SearchResults query={actualQuery} {...{queryField, loading, setLoading}}/> :
                        <NoQueryYet {...{processing, processed}}/>
                }
            </section>
        </div>
    );
};

// <th>
//     Datum
// </th>
// <td>{doc.date}</td>

export default Home;
