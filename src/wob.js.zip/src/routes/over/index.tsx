// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h} from 'preact';
import style from './style.css';
import TextPage from "../../components/textpage";

interface OverProps {

}

const Profile: FunctionalComponent<OverProps> = (props: OverProps) => {
    //const [time, setTime] = useState<number>(Date.now());
    //const [count, setCount] = useState<number>(0);

    // gets called when this route is navigated to
    // useEffect(() => {
    //     const timer = window.setInterval(() => setTime(Date.now()), 1000);
    //     // gets called just before navigating away from the route
    //     return (): void => { clearInterval(timer); };
    // }, []);
    //
    // // update the current time
    // const increment = (): void => {
    //     setCount(count + 1);
    // };

    return (
        <TextPage>
            <h3>Waarom</h3>
            <p class={style.condensedbottompadding}>
                Ik ben dit project begonnen na het beluisteren van de podcast <a
                href="https://www.nporadio2.nl/podcasts/op-zn-kop/66041/49-op-zn-kop-met-data-speurders-wouter-aukema-en-marc-van-der-vegt">OP
                Z'N KOP! <em>#49 Met data-speurders Wouter Aukema en Marc van der Vegt</em></a>. In deze aflevering
                wordt geklaagd dat het ministerie WOB-verzoeken beantwoordt met een overweldigend pak PDF's van gefotografeerde
                documenten, wat het zeer onhandig maakt om te doorzoeken. Dit inspireerde mij om een tool te maken die
                al deze documenten machine-leesbaar, dus doorzoekbaar, maakt. Ik leerde dat het
                Telegram-kanaal Klokkenluiders een initiatief is begonnen om met zijn allen de documenten van het
                WOB-verzoek inzake corona te doorspitten (<a href="https://t.me/wobonderzoek">@wobonderzoek</a>).
                Hoewel ik politiek niet altijd 100% op één lijn zit met alle 'data-speurders', vind ik
                dit wel een heel interessant initiatief in burgerjournalistiek en
                participatieve democratie.
            </p>
            <h3>
                Steun mij
            </h3>
            <p class={style.condensedbottompadding}>
                Ik ben dit project begonnen als zelfstandige vrijwilliger. Ik ben niet gelieerd aan een beweging of organisatie.
                Mocht je mij willen steunen, kun je een donatie maken. Dat helpt me dit
                platform verder te ontwikkelen en serverkosten te dekken (lezen en indexeren van de documenten kost veel
                rekenkracht) dus wordt zeer gewaardeerd!
            </p>

            <div class={style.donatieblock}>
            <div class={style.qrwrapper}>
                <a class={style.donatie}
                   href="https://www.ing.nl/particulier/betaalverzoek/index.html?trxid=FgOgedZ7hMhUdSAsHjJswdv1iMBS2yWj">
                    {/*<span style="font-weight: bold;text-size: 0.7em;">M. F. A. Trompper</span><br/>*/}
                    <div class={style.donatiewrapper}>
                        <img class={style.donatieqr} src="/assets/img/donatie20220508.svg"/>
                        <strong>Donatie (€10)</strong>
                    </div>
                </a>
                <div class={style.reknr}>
                    <code>NL92INGB0009085809</code><br/> t.a.v. <code>M. F. A. Trompper</code>
                </div>
            </div>
            </div>

            <p>
                Mocht je me immaterieel willen steunen met vriendelijke woorden of data, kun je een e-mail sturen
                naar <a href="mailto:maartentrompper+wob@freedom.nl">maartentrompper+wob@freedom.nl</a>.
            </p>

            <p class={style.condensedbottompadding}>
                Je kunt ook één van mijn apps kopen voor <a
                href="https://play.google.com/store/apps/developer?id=Black+Envelope">Android</a> of <a
                href="https://apps.apple.com/be/developer/maarten-trompper/id1458861334">iOS</a>.
            </p>

            <h3>Meer informatie</h3>
            <p>
                Wees alsjeblieft redelijk. Ambtenaren moeten burgers
                niet pesten door informatie te obscureren en burgers moeten ambtenaren niet pesten door te WOB-trollen.
                Iedereen heeft belang bij wederzijdse eerlijkheid, respect en transparantie.
            </p>

            <p>Een grote inspiratie voor mij is <a
                href="https://hbr.org/podcast/2020/10/how-taiwan-is-using-technology-to-foster-democracy-with-digital-minister-audrey-tang">Audrey
                Tang</a>, die als digitale minister van Taiwan verantwoordelijk is voor een aantal innovatieve projecten
                voor het betrekken van burgers bij bestuur, en het bereiken van eerlijke en bona fide consensus.
            </p>

        </TextPage>
    );
};

export default Profile;
