// noinspection HtmlUnknownAttribute

import {FunctionalComponent, h, JSX} from 'preact';
import {useEffect, useState} from 'preact/hooks';
import style from './style.css';
import {ReconstructedDoc} from "../../model/ocrdocument/ReconstructedDoc";
import {
    fetchMetadataForDoc,
    getReconstructedPages,
    ProcessedDocWithBatchId
} from "../../model/ocrdocument/FetchDocumentContents";
import DocPlainText from "../../components/docs/docplaintext";
import DocReconstructed from "../../components/docs/docreconstructed";
import {PlainTextState} from "../../model/ocrdocument/PlainTextState";
import {normalizeError} from "../../model/util/errhelpers";
import LoadingPara from "../../components/loadingpara";
import {Link} from 'preact-router';
import LinkButtons from "../../components/headerlinksfordoc";
import ErrPara from "../../components/errpara";
import DocsRowWithTitle from "../../components/docs/docsrowtitle";


export interface TestDocProps {
    batchid?: string;
}

const TestDoc: FunctionalComponent<TestDocProps> = (props: TestDocProps) => {
    const {batchid} = props;
    //const [time, setTime] = useState<number>(Date.now());
    const [reconstructedPage, setReconstructedPage] = useState<ReconstructedDoc | undefined>(undefined);
    const [plainText, setPlainText] = useState<PlainTextState | undefined>(undefined);
    const [docDisplayType, setDocDisplayType] = useState<string>("reconstructed"); // plaintext
    const [metadata, setMetadata] = useState<ProcessedDocWithBatchId | undefined>(undefined); // plaintext

    // gets called when this route is navigated to
    useEffect(() => {
            if (!!batchid && (!metadata || metadata.batchid !== batchid)) {
                fetchMetadataForDoc(batchid)
                    .then(m => {
                        setPlainText(m);
                        setMetadata(m);
                    })
                    .catch(e => {
                            const err = normalizeError(e);
                            const errState = {
                                batchid,
                                fullText: err.message,
                                tgMsgId: -1,
                                fileName: err.message,
                                title: err.message,
                                err,
                            };
                            setMetadata(errState);
                            setPlainText(errState);
                        }
                    ); // todo handle errors!
            }
            //const timer = window.setInterval(() => setTime(Date.now()), 1000);
            switch (docDisplayType) {
                case "plaintext":// we get plaintext from metadata call
                    // if (!plainText || plainText.batchid !== batchid) {
                    //     // load if not loaded yet
                    //     //setPlainText({batchid, text: "", loading: true});
                    //     getPlainTextForDoc(batchid)
                    //         .then((text) => setPlainText({batchid, text}));
                    // }
                    break;
                default:
                    if (!!batchid && (!reconstructedPage || reconstructedPage.id !== batchid)) {
                        // load if not loaded yet
                        getReconstructedPages(batchid)
                            .then((e) => setReconstructedPage(e))
                            .catch((err) => setReconstructedPage({id: batchid, pages: [], err}));
                    }
                    break;
            }
            // gets called just before navigating away from the route
            return (): void => {
                // // todo misschien batchid toevoegen aan die params zodat we weten of hij fresh of stale is!
                // setReconstructedPage(undefined);
                // setPlainText("");
            };
        },
        [
            batchid,
            docDisplayType,
        ]);

    const title = metadata?.title || batchid?.replace(/[+_-]+/g, " ")?.replace(/[a-z0-9]+\s*$/, "");

    const resetDocDisplayType: JSX.GenericEventHandler<HTMLInputElement> = e => {
        const value = (e.target as HTMLInputElement).value;
        //console.log(value);
        setDocDisplayType(value)
    };
    // <a class={style.srclink} href={"tg://url"}>(bron)</a>
    return (
        <div class={style.docholder}>
            <nav class={style.dochead}>
                <h2 class={style.doctitle}>{title || "GEEN DOCUMENT GESELECTEERD"}</h2>
                {/*<DocsRowWithTitle doc={doc}/>*/}
                {
                    metadata ? (metadata.err ? <ErrPara what={"document"} err={metadata.err}/> :
                        <LinkButtons
                            // https://web.telegram.org/z/#-1591000094_
                            // -1591000094
                            tgMsgId={412}
                            batchid={metadata.batchid}
                            channel="toncoin"
                        />) : <LoadingPara/>
                }
            </nav>
            <div class={style.doccontainer}>
                <div class={style.selecttextkind}>
                    <div class={style.radioholder}>
                        <input
                            type="radio"
                            checked={docDisplayType == "reconstructed"}
                            name="docdisplay"
                            value="reconstructed"
                            id="reconstructed"
                            onChange={resetDocDisplayType}
                        />
                        <label className={style.labeldocdisplay} htmlFor="reconstructed">Geherconstrueerd
                            document</label>
                    </div>
                    <div class={style.radioholder}>
                        <input
                            type="radio"
                            checked={docDisplayType == "plaintext"}
                            name="docdisplay"
                            value="plaintext"
                            id="plaintext"
                            onChange={resetDocDisplayType}
                        /><label className={style.labeldocdisplay} htmlFor="plaintext">Platte&nbsp;text</label>
                    </div>
                </div>
                <p class={style.visualwarning}>Dit is een weergave van de uitvoer van <a
                    href="https://nl.wikipedia.org/wiki/Optical_character_recognition">automatische tekstherkenning</a>,
                    bedoeld om gefotografeerde tekst makkelijk doorzoekbaar te maken. Visuele
                    elementen zoals kaders, kleuren en opmaak zijn grotendeels verwijderd, maar tegelijk is het document
                    verrijkt met informatie over de positie van herkende letters en woorden. Download hieronder de
                    oorspronkelijke PDF of ruwe data van de tekstherkenning. Een dump van alle documenten is <Link
                        href="/dump">hier</Link> beschikbaar.
                </p>
                {
                    docDisplayType === "plaintext" ? <DocPlainText {...{plainText}}/> :

                        reconstructedPage ? reconstructedPage.err ?
                                <p class={style.err}>Kon document niet laden: {reconstructedPage.err.message}. Laat de
                                    beheerder weten dat deze
                                    fout plaatsvond.</p> : <DocReconstructed doc={reconstructedPage}/> :
                            <LoadingPara center={true}/>
                }
            </div>
        </div>
    );
};


export default TestDoc;
