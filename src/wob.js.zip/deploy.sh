#sdk install kotlin
kotlin generate_sitemap.kts

npm run build

cp -rf src/public/* production/public/
cp -rf build/* production/public/

echo "Moved files to folder!"

cd production
git pull
git add .
git commit -am "etc"
git push origin master -u