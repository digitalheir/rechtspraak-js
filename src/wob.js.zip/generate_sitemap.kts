import org.w3c.dom.Document
import org.w3c.dom.Node
import java.io.FileOutputStream
import java.io.OutputStream
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.*
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

val urlRoot = "https://wob.lawreader.nl/"

val consolidatedFolder = java.nio.file.Paths.get("production/public/consolidated")
//println("Working Directory = " + System.getProperty("user.dir"))
//println("Consolidated folder = " + consolidatedFolder.absolutePath)

data class SitemapUrl(val url: String, val lastModified: String, val priority: String = "0.5")

val urls = ArrayDeque<SitemapUrl>()
java.nio.file.Files.newDirectoryStream(consolidatedFolder).forEach { file ->
    if (!java.nio.file.Files.isDirectory(file)) {
        val attr = java.nio.file.Files.readAttributes(file, java.nio.file.attribute.BasicFileAttributes::class.java)
        //println("lastModifiedTime: " + attr.lastModifiedTime())
        // FileTime
        val lastModified = attr.lastModifiedTime().toString() //  The string is returned in the ISO 8601 format: YYYY-MM-DDThh:mm:ss[.s+]Z
        val loc = "${urlRoot}doc/?batchid=${"${file.fileName}".removeSuffix(".gz").removeSuffix(".json")}"
        //println("$lastModified $loc")
        urls.add(SitemapUrl(loc, lastModified))
    }
}
val docFactory = DocumentBuilderFactory.newInstance()
val docBuilder = docFactory.newDocumentBuilder()
// root elements
val doc = docBuilder.newDocument()
val rootElement = doc.createElement("urlset")
doc.setXmlStandalone(true)
doc.appendChild(rootElement)

fun Document.writeXml(output: OutputStream) {
    val transformerFactory = TransformerFactory.newInstance()
    transformerFactory.setAttribute("indent-number", 2)
    val transformer = transformerFactory.newTransformer()
    transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8")
    transformer.setOutputProperty(OutputKeys.INDENT, "yes")
    val source = DOMSource(this)
    val result = StreamResult(output)
    transformer.transform(source, result)
}

//@Throws(IOException::class)
//fun newOutputStream(path: Path): OutputStream? {
//    return FileOutputStream(path.toFile())
//}
rootElement.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
rootElement.setAttribute("xsi:schemaLocation", "http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd")
rootElement.setAttribute("xmlns", "http://www.sitemaps.org/schemas/sitemap/0.9")
val staticPages = listOf(
    SitemapUrl(urlRoot, "2022-07-19T15:51:51.477522Z"),
    SitemapUrl(urlRoot + "dump", "2022-07-19T15:51:51.477522Z"),
//    SitemapUrl(urlRoot + "doc", "2022-07-19T15:51:51.477522Z"),
//    SitemapUrl(urlRoot + "over", "2022-07-19T15:51:51.477522Z"),
)
staticPages.forEach(::node)
urls.forEach(::node)
// write dom document to a file
//tr.transform( DOMSource(dom), new StreamResult(new FileOutputStream(xml)));
doc.writeXml(FileOutputStream("production/public/sitemap.xml"))

fun node(url: SitemapUrl) {
    rootElement.appendChild(doc.createElement("url").also { elUrl ->
        elUrl.appendChild(doc.createElement("loc").also { elLoc ->
            elLoc.appendChild(doc.createTextNode(url.url))
        })
        elUrl.appendChild(doc.createElement("lastmod").also { elLm ->
            elLm.appendChild(doc.createTextNode(url.lastModified))
        })
        elUrl.appendChild(doc.createElement("changefreq").also { elCf ->
            elCf.appendChild(doc.createTextNode("never"))
        })
        elUrl.appendChild(doc.createElement("priority").also { elPrio ->
            elPrio.appendChild(doc.createTextNode(url.priority))
        })
    })
}

println("Written sitemap.xml!")