
module.exports = function (config, env) {
    if (env.isProd) {
        config.devtool = false; // disable sourcemaps
    }
}

// export default function (config, env, helpers) {
//     //...
//     helpers.getPluginsByName(config, "UglifyJsPlugin")[0].plugin.options.sourceMap = false;
//     //...
// }